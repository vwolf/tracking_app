import 'dart:async';
import 'dart:io';

import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

import 'models/tour.dart';
import 'tourTable.dart';

class DBProvider {
  final dataBaseName = "TracksDB.db";

  TourTable _tourTable;

  DBProvider._();
  static final DBProvider db = DBProvider._();
  static Database _database;

  Future<Database> get database async {
    if (_database != null)
      return _database;

    _tourTable = TourTable();
    _database = await _initDB(dataBaseName);

    return _database;
  }

  _initDB(dbName) async {
    Directory documentsDirectory = await getApplicationDocumentsDirectory();
    String path = join(documentsDirectory.path, dbName);
    return await openDatabase(path, version: 1, onOpen: (db) {},
      onCreate: (Database db, int version) async {
        var tourTableState = _tourTable.createTourTable(db);
        print('_initDb.createTourTable: $tourTableState');
      }
    );
  }

  /// TourTable queries
  newTour(Tour newTour) async {
    final db = await database;
    return _tourTable.newTour(db, newTour);
  }

  updateTour(Tour tour) async {
    final db = await database;
    return _tourTable.updateTour(db, tour);
  }

  deleteTour(int id) async {
    final db = await database;
    return _tourTable.deleteTour(db, id);
  }

  Future<List<Tour>> getAllTours() async {
    final db = await database;
    return _tourTable.getAllTours(db);
  }

  isTableExisting(String tablename) async {
    final db = await database;
    return _tourTable.isTableExisting(db, tablename);
  }

  tourExists(String tourname) async {
    final db = await database;
    return _tourTable.tourExists(db, tourname);
  }


}