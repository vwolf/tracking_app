import 'dart:async';
import 'package:sqflite/sqflite.dart';
import 'models/tour.dart';
//import 'models/tourCoord.dart';
import 'models/tourItem.dart';
import 'tourItemTable.dart';

class TourTable {
  TourTable();

  createTourTable(Database db) async {
    print("createTourTable");

    try {
      var res = db.transaction((txn) async {
        await txn.execute("CREATE TABLE TOUR ("
            "id INTEGER PRIMARY KEY,"
            "name TEXT,"
            "description TEXT,"
            "timestamp TEXT,"
            "open BIT,"
            "location TEXT,"
            "tourImage TEXT,"
            "options TEXT,"
            "coords TEXT,"
            "track TEXT,"
            "items TEXT,"
            "createdAt TEXT )");
      });
      print("collection Tour create ok: $res");
      return res;
    } on DatabaseException catch (e) {
      print("sqlite error: $e");
      return false;
    }
  }


  /// Tour names have to be unique
  Future newTour(Database db, Tour newTour) async {
    print("db newTour");
    // get biggest id in the table
    var table = await db.rawQuery("SELECT MAX(id)+1 as id FROM TOUR");
    int id = table.first["id"];
    // join all parts of tourname with '_'
    var modTourname = newTour.name.replaceAll(new RegExp(r' '), '_');
    // create trackTable for tour
    var createTableResult = await createTourTrackTable(db, modTourname);
    print("CreateTourTrackTable: " + createTableResult);
    newTour.track = createTableResult;

    var createTableItems = await createTourItemTable(db, modTourname);
    print("CreateTourItemTable: " + createTableItems);
    newTour.items = createTableItems;

    // insert into the table using new id
    print("Start insert new Tour");
    newTour.id = id;
    newTour.createdAt = DateTime.now().toIso8601String();
    var res = await db.insert("TOUR", newTour.toMap());
    return res;
  }


  /// createdAt: date string ISO8601
  createTourTrackTable(Database db, String tourName) async {
    String tourTrackTableName = "TourTrack_" + tourName;
    try {
      var res = db.transaction((txn) async {
        await txn.execute("CREATE TABLE " +
            tourTrackTableName +
            " (id INTEGER PRIMARY KEY,"
                "latitude REAL,"
                "longitude REAL,"
                "altitude REAL,"
                "timestamp TEXT,"
                "accuracy REAL,"
                "heading REAL,"
                "speed REAL,"
                "speedAccuracy REAL,"
                "item INTEGER"
                ")");
      });
      return tourTrackTableName;
    } on DatabaseException catch (e) {
      print("sqlite error: $e");
      return false;
    }
  }

  createTourItemTable(Database db, String tourName) async {
    String tourItemTableName = "TourItem_" + tourName;
    return await TourItemTable().createTourItemTable(db, tourName);
  }

  updateTour(Database db, Tour tour) async {
    print("updateTour");
    try {
      var res = await db
          .update("TOUR", tour.toMap(), where: "id = ?", whereArgs: [tour.id]);
      return 1;
    } on DatabaseException catch (e) {
      print("sqlite error $e");
    }
    return 0;
  }

  addCoord(Database db, String coord) async {
    try {
      return 1;
    } on DatabaseException catch (e) {
      print("sqlite error $e");
    }
    return 0;
  }

  deleteTour(Database db, int id) async {
    print("deleteTour with id $id");
    return db.delete("Tour", where: "id = ?", whereArgs: [id]);
  }

  Future<List<Tour>> getAllTours(Database db) async {
    print("getAllTours");
    try {
      var res = await db.query("TOUR");
      List<Tour> list =
      res.isNotEmpty ? res.map((c) => Tour.fromMap(c)).toList() : [];

      print(list);
      return list;
    } on DatabaseException catch (e) {
      print("sqlite error: $e");
    }

    return [];
  }

  Future<int> isTableExisting(Database db, String tablename) async {
    var result = await db.rawQuery(
        "SELECT name FROM sqlite_master WHERE type='table' AND name= ?",
        [tablename]);
    if (result.length > 0) {
      print("table $tablename exists");
      return result.length;
    } else {
      print("table $tablename does not exists");
      var tableCreated = await createTourTable(db);
      if (tableCreated == true) {
        return 1;
      }
    }
    return null;
  }

  Future<int> tourExists(Database db, String query) async {
    try {
      List<Map> maps =
      await db.rawQuery("SELECT id FROM TOUR WHERE name = ? ", [query]);
      if (maps.length > 0) {
        return maps.length;
      }
    } on DatabaseException catch (e) {
      print("Sqlite error: $e");
    }
    return null;
  }

}