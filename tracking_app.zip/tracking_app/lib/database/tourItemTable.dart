import 'package:sqflite/sqflite.dart';
import 'models/tourItem.dart';

class TourItemTable {
  TourItemTable();

  createTourItemTable(Database db, String tourName) async {
    print("createTourItemTable");
    String tourItemTableName = "TourItem_" + tourName;
    try {
      var res = db.transaction((txn) async {
        await txn.execute("CREATE TABLE " +
            tourItemTableName +
            "(id INTEGER PRIMARY KEY,"
                "name TEXT,"
                "info TEXT,"
                "timestamp TEXT,"
                "latlng TEXT,"
                "images TEXT,"
                "createdAt TEXT,"
                "markerId INTEGER"
                ")"
        );
      });
      return tourItemTableName;
    } on DatabaseException catch (e) {
      print("sqlite error: $e");
      return false;
    }
  }

}