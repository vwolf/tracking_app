import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:latlong/latlong.dart';

import '../database/database.dart';
import '../database/models/tour.dart';

/// Create or updata an track
class NewTrackPage extends StatefulWidget {
  Tour tour = Tour();

  NewTrackPage();

  NewTrackPage.withTour(Tour tour) {
    this.tour = tour;
  }

  @override
  _NewTrackPageState createState() => _NewTrackPageState();
}


class _NewTrackPageState extends State<NewTrackPage> {

  bool _newTrack = true;
  bool _formSaved = false;
  String _gpxFilePath;

  // form key and controller
  final _formkey = GlobalKey<FormState>();
  final _formNameController = TextEditingController();
  final _formDescriptionController = TextEditingController();
  final _formLocationController = TextEditingController();
  final _formStartLatitudeController = TextEditingController();
  final _formStartLongitudeController = TextEditingController();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: _newTrack == true ? Text("New Track") : Text("Update Track"),
      ),
      body: ListView(
        children: <Widget>[
          _form,
          _tourImage,
        ],
      ),
    );
  }


  Future getTrack() async {

  }

  Future getImage() async {

  }

  /// Used as closure in SubmitBtnWithState
  /// Track exists?
  Future submitEvent(int i) async {
    print('submit event $i');
    var trackExists = await DBProvider.db.tourExists(_formNameController.text);
    if (trackExists != null) {
      /// TODO Track update
      return false;
    }

    /// New Track
    if (_formkey.currentState.validate()) {
      widget.tour.name = _formNameController.text;
      widget.tour.description = _formDescriptionController.text;
      widget.tour.location = _formLocationController.text;
      widget.tour.open = false;

      /// Start coordinates
      LatLng startCoords = LatLng(
          double.parse( _formStartLatitudeController.text),
          double.parse( _formStartLongitudeController.text)
      );
      widget.tour.coords = jsonEncode(startCoords);

      /// Gpx file path
      if (_gpxFilePath != null) {
        widget.tour.options = jsonEncode({"gpxFilePath": _gpxFilePath});
      }

      /// Add timestamp to track (created or modified)
      widget.tour.timestamp = DateTime.now();

      /// Write to db
      var dbResult = await DBProvider.db.newTour(widget.tour);
      print(dbResult);
      _formSaved = true;
    }
  }


  Widget get _form {
    return Form(
      key: _formkey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: TextFormField(
              controller: _formNameController,
              keyboardType: TextInputType.text,
              textInputAction: TextInputAction.done,
              decoration: InputDecoration(labelText: 'Enter name'),
              validator: (value) {
                if (value.isEmpty) {
                  return "Please enter a name";
                }
              },
              maxLines: 1,
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: TextFormField(
              controller: _formDescriptionController,
              decoration: InputDecoration(labelText: 'Enter Description'),
              validator: (value) {
                if (value.isEmpty) {
                  return 'Please enter some text';
                }
              },
              maxLines: null,
            )
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: TextFormField(
              controller: _formLocationController,
              textInputAction: TextInputAction.done,
              decoration: InputDecoration(labelText: 'Enter Location name'),
              validator: (value) {
                if (value.isEmpty) {
                  return 'Please enter location name';
                }
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 16.0, top: 8.0),
            child: Text('Start Coordinates'),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 16.0, top: 8.0, right: 16.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                Flexible(
                    child: TextFormField(
                      controller: _formStartLatitudeController,
                      decoration: InputDecoration(labelText: 'Latitude'),
                      keyboardType: TextInputType.number,
                    )
                ),
                Flexible(
                  child: TextFormField(
                    controller: _formStartLongitudeController,
                    decoration: InputDecoration(labelText: 'Longitude'),
                    keyboardType: TextInputType.number,
                  ),
                ),
                FlatButton.icon(
                    onPressed: null,
                    icon: Icon(Icons.add),
                    label: Text(' '),
                ),
              ],
            ),
          ),
          Padding(
              padding:
              const EdgeInsets.symmetric(horizontal: 8.0, vertical: 16.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: <Widget>[
                  SubmitBtnWithState(submitEvent, 'Processing'),
                  RaisedButton(
                    child: Text('Load from GPX'),
                    onPressed: getTrack,
                  ),
                  FlatButton.icon(
                    onPressed: _formSaved == true ? getImage : null,
                    icon: new Icon(Icons.image),
                    label: Text('Add Image'),
                    disabledColor: Colors.black26,
                  ),
                ],
              )),
        ]),
    );
  }

  Widget get _tourImage {
    if (widget.tour.tourImage != null ) {
      return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 12.0),
        child: Container(
          height: 80.0,
          alignment: Alignment.topLeft,
          decoration: BoxDecoration(
            shape: BoxShape.rectangle,
            image: DecorationImage(
              fit: BoxFit.fitHeight,
                image: AssetImage(widget.tour.tourImage),
            ),
          ),
        )
      );
    } else {
      return Container(
        height: 0.0,
      );
    }
  }
}


class SubmitBtnWithState extends StatefulWidget {
  final void Function(int) callback;
  final String btnText;

  SubmitBtnWithState(this.callback, this.btnText);

  @override
  _SubmitBtnWithState createState() => _SubmitBtnWithState();
}

/// State for class SubmitBtnWithState
class _SubmitBtnWithState extends State<SubmitBtnWithState> {

  @override
  Widget build(BuildContext context) {
    return RaisedButton(
      child: Text('Submit'),
      onPressed: () {
        widget.callback(1);
        Scaffold.of(context).showSnackBar(
          SnackBar(
              content: Text(widget.btnText),
              duration: Duration(seconds: 2),
          )
        );
      },
    );
  }
}